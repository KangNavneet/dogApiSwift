//
//  DogBreed.swift
//  dogApiProject
//
//  Created by user165323 on 10/2/20.
//  Copyright © 2020 NavneetKang. All rights reserved.
//
import Foundation

class DogBreed {
    
    var name:String?
    var remoteUrl: String?
    var subBreeds: [String]?
}

