//
//  dogApi.swift
//  dogApiProject
//
//  Created by user165323 on 10/2/20.
//  Copyright © 2020 NavneetKang. All rights reserved.
//

//
//  dogApi.swift
//  dogApiAssignment
//
//  Created by user165323 on 9/30/20.
//  Copyright © 2020 NavneetKang. All rights reserved.
//
import Foundation

//Structure of JSON API CREATED
struct jsonDog: Decodable {
    
    var message: [String:[String]]?
    var status: String?
}

class dogApi {
    
    let dogListUrl = "https://dog.ceo/api/breeds/list/all"
    
    func getDogBreeds(completion: @escaping ((jsonDog?) -> Void)) {
        
        let url = URL(string :dogListUrl)
        let request = URLRequest(url: url!)
        URLSession.shared.dataTask(with: request){
            (data, response, error) in
            
            guard let responseData = data else { return }
            
            //Serialize json response
            do {
                let data = try JSONDecoder().decode(jsonDog.self, from: responseData)
                
                //Print all dog breeds
                print("Response:\(data)")
                completion(data)
            }
            catch let error {
                print("Error message:\(error)")
               completion(nil)
                
            }
            
            
        }.resume()
    }
}

