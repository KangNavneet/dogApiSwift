//
//  ViewController.swift
//  dogApiProject
//
//  Created by user165323 on 10/2/20.
//  Copyright © 2020 NavneetKang. All rights reserved.
//


import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

  
    @IBOutlet weak var tableView: UITableView!
    
    var breedOfDog = [DogBreed]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        tableView.delegate = self
        tableView.dataSource = self
        tableView.separatorColor = .green
        
        let dogJsonObj = dogApi()
        dogJsonObj.getDogBreeds {
            (data) in
            
            
            
             guard let parsedJson = data else { return }
                
                if let items = parsedJson.message {
                    for item in items {
                        let breed = DogBreed()
                        breed.name = item.key
                        breed.subBreeds = item.value
                        self.breedOfDog.append(breed)
                    }
                    DispatchQueue.main.async {
                        self.sortAscendBreed()
                        self.navigationItem.title = "DOG API :::Dog Breeds & Sub-Breeds"
                    }
                }
     }
        
        
    }

    func sortAscendBreed (){
        breedOfDog.sort {
            (arg1, arg2) -> Bool in
                arg1.name?.caseInsensitiveCompare(arg2.name!) == .orderedAscending
            
        }
        self.tableView.reloadData()
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return breedOfDog.count
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return ""
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        let breed = breedOfDog[indexPath.row]
        cell.textLabel?.text = breed.name ?? ""
        cell.selectionStyle = .none
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 0
    }
    
//    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//        
//        self.performSegue(withIdentifier: "showBreedIdentifier", sender: self)
//    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        print("prepare for segue called.")
        if segue.identifier == "showBreedIdentifier" {
            let viewController = segue.destination as! DogDetailViewController
            
            if let indexPath = tableView.indexPathForSelectedRow{
                print("indexPath = \(indexPath)")
                viewController.dog = breedOfDog[indexPath.row]
            } else {
                print("indexPath does not exist")
            }
        }
    }
}

