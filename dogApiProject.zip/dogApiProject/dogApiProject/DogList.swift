//
//  DogList.swift
//  dogApiProject
//
//  Created by user165323 on 10/2/20.
//  Copyright © 2020 NavneetKang. All rights reserved.
//

import Foundation

class DogList {
    
    let imageDataUrl = "https://images.dog.ceo/breeds/newfoundland/n02111277_2636.jpg"
    
    func getRandomBreed(completion: @escaping ((Data?)-> Void)) {
        
        let url = URL(string: imageDataUrl)
        let request = URLRequest(url: url!)
        URLSession.shared.dataTask(with: request) { (data, response, error) in
            
            guard let responseData = data else { return }
            completion(responseData)
            
        }.resume()
    }
}
