//
//  DogDetailViewController.swift
//  dogApiProject
//
//  Created by user165323 on 10/2/20.
//  Copyright © 2020 NavneetKang. All rights reserved.
//


import UIKit

class DogDetailViewController: UIViewController {
    
    var data: Data?
    
 @IBOutlet weak var imageView: UIImageView!
    
    var dog: DogBreed!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        

        
          
//        if let img = data {
//            self.imageView.image = UIImage(data: img)
//        }
//        else {
//            // There are no images asscoiated with Dogs object in the api repsonse so using a random image .
//            DogList().getRandomBreed{ (data) in
//                guard let img = data else { return }
//                DispatchQueue.main.async {
//                    self.imageView.image = UIImage(data: img)
//                }
//            }
//        }

    }
}
